package annotator.tests;

public class MatchReturnValue<T> {

  public MatchReturnValue<T> clone() {
    return this;
  }
}
