/** Test of package annotations. */
@SimplerAnnotation(
    be = BalanceEnum.BALANCED,
    height = 0,
    wrappedHeight = {1},
    favoriteClass = Object.class)
package org.checkerframework.afu.scenelib.toys;
