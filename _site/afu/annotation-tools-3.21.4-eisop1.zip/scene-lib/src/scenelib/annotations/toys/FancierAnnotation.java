package scenelib.annotations.toys;

public @interface FancierAnnotation {
  FancyAnnotation fa();
}
