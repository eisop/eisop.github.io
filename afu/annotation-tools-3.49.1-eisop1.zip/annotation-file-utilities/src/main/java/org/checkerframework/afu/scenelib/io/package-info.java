/**
 * <code>org.checkerframework.afu.scenelib.io</code> provides classes for the input and output of
 * {@link org.checkerframework.afu.scenelib.el.AScene}s to/from various formats.
 */
package org.checkerframework.afu.scenelib.io;
