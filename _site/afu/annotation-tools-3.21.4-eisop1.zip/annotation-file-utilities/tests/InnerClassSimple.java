package annotator.tests;

import java.util.Date;

public class InnerClassSimple {
  public Integer field;

  public class ActualInnerClass {
    Date d;
  }
}
