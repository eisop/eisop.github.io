package org.checkerframework.afu.scenelib.toys;

public @interface SubAnnotation {
  int[] value();
}
