package org.checkerframework.afu.annotator.tests;

public class EnumAnnotationParameter {
  public void foo() {}
}
