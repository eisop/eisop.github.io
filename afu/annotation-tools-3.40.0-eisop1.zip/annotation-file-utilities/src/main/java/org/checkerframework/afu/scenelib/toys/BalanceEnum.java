package org.checkerframework.afu.scenelib.toys;

public enum BalanceEnum {
  BALANCED,
  LEFT_HEAVY,
  RIGHT_HEAVY;
}
