/**
 * This package contains annotations to use on the test files used by {@link
 * org.checkerframework.afu.scenelib.test.classfile.AnnotationsTest}.
 */
package annotations.tests.classfile.foo;
