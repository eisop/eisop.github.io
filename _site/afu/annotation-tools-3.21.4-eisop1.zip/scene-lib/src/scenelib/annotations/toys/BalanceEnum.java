package scenelib.annotations.toys;

public enum BalanceEnum {
  BALANCED,
  LEFT_HEAVY,
  RIGHT_HEAVY;
}
