/** A package without any annotations. */
package org.checkerframework.afu.annotator.tests;
