public class ParseType<E> {
  void m(Object o) {
    Object o0 = o;
    Object o1 = o;
    Object o2 = o;
    Object o3 = o;
    Object o4 = o;
    Object o5 = o;
    Object o6 = o;
    Object o7 = o;
    Object o8 = o;
    Object o9 = o;
    Object o10 = o;
    Object o11 = o;
  }

  public class Inner<K> {}
}
