#!/bin/bash

## TODO: Eliminate this script, which exists for backward compatibility.

echo "Don't use .travis-build-without-test.sh; use .build-without-test.sh instead."

source .build-without-test.sh
