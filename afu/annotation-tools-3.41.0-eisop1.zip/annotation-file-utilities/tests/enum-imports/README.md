This is a separate directory because it calls the afu with
  --abbreviate=true
whereas the rest of the tests use --abbreviate=false.
