public class C {
  Object f;
}
