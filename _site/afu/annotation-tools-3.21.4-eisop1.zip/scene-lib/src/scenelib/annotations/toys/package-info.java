@SimplerAnnotation(
    be = BalanceEnum.BALANCED,
    height = 0,
    wrappedHeight = {1},
    favoriteClass = Object.class)
package scenelib.annotations.toys;
