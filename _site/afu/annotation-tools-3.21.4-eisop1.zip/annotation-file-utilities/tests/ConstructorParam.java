package annotator.tests;

public class ConstructorParam {
  public ConstructorParam(int paramB) {}
}
