public class NewPackage {
  public NewPackage() {
    Object o = new java.util.LinkedList();
  }
}
