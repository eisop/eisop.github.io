import java.util.Map;

public class MethodCompoundType {
  public Map[] m() {
    return null;
  }
}
