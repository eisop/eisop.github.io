package org.checkerframework.afu.annotator.tests;

public class Date {
  private long t;
}
