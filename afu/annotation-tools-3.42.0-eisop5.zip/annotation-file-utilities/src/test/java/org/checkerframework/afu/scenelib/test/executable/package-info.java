/** This package is for tests that are not JUnit tests. */
package org.checkerframework.afu.scenelib.test.executable;
