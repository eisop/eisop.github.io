The files in this directory are used by `org.checkerframework.afu.scenelib.test.classfile.TestSceneLib`.
