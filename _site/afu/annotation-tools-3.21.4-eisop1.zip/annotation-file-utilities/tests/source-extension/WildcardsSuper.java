import java.util.*;

public class WildcardsSuper {
  Enumeration<? super WildcardsSuper> f;
}
