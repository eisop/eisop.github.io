package org.checkerframework.afu.annotator.tests;

public class ConstructorParam {
  public ConstructorParam(int paramB) {}
}
