class ArrayLiteral {
  int[] s0 = {};
  int[] s1 = {0, 1};
  String[] s2 = {"TEST"};
  String[] s3 = {"TEST"};
}
