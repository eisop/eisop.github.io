package org.checkerframework.afu.annotator.tests;

public class ClassAnnotationParameter {
  public void foo() {}
}
