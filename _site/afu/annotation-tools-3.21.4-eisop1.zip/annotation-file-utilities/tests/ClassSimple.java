package annotator.tests;

public class ClassSimple {
  public Integer field;
}
