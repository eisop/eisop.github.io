/** <code>annotations.field</code> provides classes that store the types of annotation fields. */
package org.checkerframework.afu.scenelib.field;
