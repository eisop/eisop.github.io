package org.checkerframework.afu.annotator.tests;

public class DeclarationAnnotation {
  public void foo() {}
}
