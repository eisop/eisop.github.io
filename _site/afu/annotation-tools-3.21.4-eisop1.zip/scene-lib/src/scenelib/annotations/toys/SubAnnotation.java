package scenelib.annotations.toys;

public @interface SubAnnotation {
  int[] value();
}
