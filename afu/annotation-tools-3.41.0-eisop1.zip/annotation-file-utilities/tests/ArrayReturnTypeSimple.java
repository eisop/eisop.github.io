package org.checkerframework.afu.annotator.tests;

public class ArrayReturnTypeSimple {
  private Object[] foo() {
    return null;
  }
}
