Annotation Tools README file
----------------------------

This directory contains the Annotation Tools.
When distributed, this is known as the Annotation File Utilities, which is
one of its components; see the annotation-file-utilities subdirectory.

The Annotation File Utilities homepage is:
  https://checkerframework.org/annotation-file-utilities/
and it also appears in this directory as:
  annotation-file-utilities/annotation-file-utilities.html
