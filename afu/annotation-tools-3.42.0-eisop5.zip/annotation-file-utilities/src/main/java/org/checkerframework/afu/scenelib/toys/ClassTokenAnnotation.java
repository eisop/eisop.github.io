package org.checkerframework.afu.scenelib.toys;

public @interface ClassTokenAnnotation {
  Class<?>[] favoriteClasses();
}
