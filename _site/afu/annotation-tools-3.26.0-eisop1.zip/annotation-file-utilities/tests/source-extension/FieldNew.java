package org.checkerframework.afu.annotator.tests;

public class FieldNew {
  Object f = new FieldNew();
}
