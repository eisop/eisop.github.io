public class ClassTV3<X, Y, Z> {
  X f;
  Y g;
  Z h;
}
