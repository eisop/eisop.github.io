#!/bin/bash

## TODO: Eliminate this script, which exists for backward compatibility.

echo "Don't use .travis-build.sh; use .build.sh instead."

source .build.sh
