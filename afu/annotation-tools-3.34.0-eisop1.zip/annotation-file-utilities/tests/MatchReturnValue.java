package org.checkerframework.afu.annotator.tests;

public class MatchReturnValue<T> {

  public MatchReturnValue<T> clone() {
    return this;
  }
}
