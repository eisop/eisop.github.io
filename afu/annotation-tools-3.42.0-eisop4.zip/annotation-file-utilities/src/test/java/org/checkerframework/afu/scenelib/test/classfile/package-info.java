/** The classes in this package are JUnit test classes. */
package org.checkerframework.afu.scenelib.test.classfile;
