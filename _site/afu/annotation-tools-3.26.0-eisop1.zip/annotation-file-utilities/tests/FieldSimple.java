package org.checkerframework.afu.annotator.tests;

public class FieldSimple {
  private Integer field;
}
