package org.checkerframework.afu.annotator.tests;

public class FieldSimpleArray {
  Integer[] field;
}
