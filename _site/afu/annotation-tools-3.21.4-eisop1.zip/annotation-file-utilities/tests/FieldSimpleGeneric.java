package annotator.tests;

import java.util.List;

public class FieldSimpleGeneric {
  List<Integer> field;
}
