package annotations.tests.classfile.cases;

public class TestClassEmpty {

}
