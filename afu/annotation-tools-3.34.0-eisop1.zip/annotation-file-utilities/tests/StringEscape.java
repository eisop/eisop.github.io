package org.checkerframework.afu.annotator.tests;

public class StringEscape {
  public void foo(String orig) {}
}
