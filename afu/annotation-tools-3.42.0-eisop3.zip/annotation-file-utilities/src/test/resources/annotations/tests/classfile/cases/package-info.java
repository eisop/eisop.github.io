/** Test case for annotation on package. */
@OnPackage
package annotations.tests.classfile.cases;

import annotations.classfile.foo.OnPackage;
