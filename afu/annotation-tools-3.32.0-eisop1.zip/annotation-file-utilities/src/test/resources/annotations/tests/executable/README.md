The files in this directory are used by the Gradle task `testExample` as input to
`org.checkerframework.afu.scenelib.test.executable.Example`.
