class ExplicitUpper<X extends Object> extends Object {}

public class ImplicitUpper<Y> {}

class Monomorphic {}
