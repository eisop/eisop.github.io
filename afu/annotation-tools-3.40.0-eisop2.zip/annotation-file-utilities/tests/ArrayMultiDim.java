package org.checkerframework.afu.annotator.tests;

import java.util.*;

public class ArrayMultiDim {
  Object[][][] field;
  Object field2 = new String[1][2][3];
  Object[][][] field3 = new Object[1][2][3];
}
