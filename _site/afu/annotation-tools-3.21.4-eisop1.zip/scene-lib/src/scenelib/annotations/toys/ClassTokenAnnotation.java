package scenelib.annotations.toys;

public @interface ClassTokenAnnotation {
  Class<?>[] favoriteClasses();
}
