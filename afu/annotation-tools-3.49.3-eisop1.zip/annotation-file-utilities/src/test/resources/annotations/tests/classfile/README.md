Used by org.checkerframework.afu.scenelib.test.classfile.AnnotationsTest.
