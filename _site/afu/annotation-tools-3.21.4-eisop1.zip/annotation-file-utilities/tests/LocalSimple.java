package annotator.tests;

public class LocalSimple {
  public void foo() {
    Object o = null;
    System.out.println(o);
  }
}
