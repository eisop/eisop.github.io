package org.checkerframework.afu.scenelib.toys;

public @interface FancierAnnotation {
  FancyAnnotation fa();
}
