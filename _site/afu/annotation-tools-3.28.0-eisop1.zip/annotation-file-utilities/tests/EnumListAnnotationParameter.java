package org.checkerframework.afu.annotator.tests;

public class EnumListAnnotationParameter {
  public void foo() {}
}
