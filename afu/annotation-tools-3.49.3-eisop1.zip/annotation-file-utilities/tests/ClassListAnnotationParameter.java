package org.checkerframework.afu.annotator.tests;

public class ClassListAnnotationParameter {
  public void foo() {}
}
