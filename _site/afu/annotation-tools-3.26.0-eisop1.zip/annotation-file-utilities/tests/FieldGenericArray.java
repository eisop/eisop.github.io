package org.checkerframework.afu.annotator.tests;

import java.util.List;

public class FieldGenericArray {
  List<Integer>[] field;
}
