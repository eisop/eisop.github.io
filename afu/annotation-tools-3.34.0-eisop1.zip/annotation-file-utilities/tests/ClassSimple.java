package org.checkerframework.afu.annotator.tests;

public class ClassSimple {
  public Integer field;
}
