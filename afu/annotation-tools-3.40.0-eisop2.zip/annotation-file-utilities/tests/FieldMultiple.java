package org.checkerframework.afu.annotator.tests;

public class FieldMultiple {
  public Integer foo, bar;
  public Integer i, d;
}
