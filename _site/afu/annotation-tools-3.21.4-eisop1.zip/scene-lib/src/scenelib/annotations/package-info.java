/**
 * <code>annotations</code> provides classes that represent annotations, their definitions, and
 * their factories.
 */
package scenelib.annotations;
