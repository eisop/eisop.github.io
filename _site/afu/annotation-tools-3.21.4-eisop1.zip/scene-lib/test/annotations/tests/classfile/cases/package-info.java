@annotations.tests.classfile.foo.OnPackage
package annotations.tests.classfile.cases;
